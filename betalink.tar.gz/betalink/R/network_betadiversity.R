#' @title Components of beta-diversity for a list of networks
#' @description
#' Given a list of networks, returns the pairwise beta-diversity components
#'
#' @param N a list of networks
#' @param ... additional arguments to be passed to \link{betalink}
#'
#' @return A dataframe with the pairwise distances
#'
#' @export
network_betadiversity <- function(N, ...){
   beta <- NULL
   for(i in c(1:(length(N)-1)))
   {
      for(j in c((i+1):length(N)))
      {
         b <- betalink(N[[i]], N[[j]], ...)
         b$i <- names(N)[i]
         b$j <- names(N)[j]
         beta <- rbind(beta, unlist(b))
      }
   }
   beta <- data.frame(beta[,c('i', 'j', 'S', 'OS', 'WN', 'ST')])
   beta$OS <- as.numeric(as.vector(beta$OS))
   beta$S <- as.numeric(as.vector(beta$S))
   beta$WN <- as.numeric(as.vector(beta$WN))
   beta$ST <- as.numeric(as.vector(beta$ST))
   return(beta)
}
