# R package betalink

Measures of network dissimilarity using R.

When using this package, please cite

> T. Poisot, E. Canard, D. Mouillot, N. Mouquet & D. Gravel (2012) The
dissimilarity of species interaction networks. *Ecology Letters*, 15 (12)
1353-1361.

