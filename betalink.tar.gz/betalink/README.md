# R package betalink

Measures of network dissimiliraty using R.

When using this package, please cite

> T. Poisot, E. Canard, D. Mouillot, N. Mouquet & D. Gravel (2012) The
dissimilarity of species interaction networks. *Ecology Letters*, 15 (12)
1353-1361.

A brief introduction can be found [on Tim's blog][betablog].

[betablog]: http://timotheepoisot.fr/2012/09/24/measuring-beta-diversity-networks/
